SHADOW MISSION — QUICK START

FILES
- index.html
- style.css
- script.js

RUN ON YOUR COMPUTER
1. Extract SHADOW_MISSION.zip.
2. Open the extracted SHADOW_MISSION folder in VS Code.
3. Make sure all three files are together in the same folder.
4. Open index.html and use Live Server, or open index.html directly in your browser.
5. Click START MISSION.

PUZZLE ANSWERS FOR TESTING
- Mission 1: 22
- Mission 2: SHADOW
- Mission 3: KEYBOARD

NOTES
- This is an offline puzzle game, not a real hacking tool.
- Progress is stored in the browser's localStorage on that device/browser.
- Google Fonts is optional; the game works without internet using fallback fonts.
- To reset saved progress, open the browser console and run:
  localStorage.removeItem("shadowMissionScore_v1");
  localStorage.removeItem("shadowMissionCompleted_v1");
  Then refresh the page.
